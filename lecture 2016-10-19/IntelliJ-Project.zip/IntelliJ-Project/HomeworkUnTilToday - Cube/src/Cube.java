/**
 * computes surface area and volume of a cube with given edge length
 */
public class Cube {

    public static void main(String[] args) {

        final int edgeLength = 5; // in millimeters

        int surfaceArea; // in millimeters
        int volume; // in millimeters

        // TODO what code to put here?

        System.out.println("The cube's surface area is " + surfaceArea + " square millimeters");
        System.out.println("The cube has a volume of " + volume + " cubic millimeters"); // TODO: what if we want to print it in cubic centimeters?

    }
}
