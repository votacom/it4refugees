/**
 * Prints numbers from 0 to 4
 */
public class Counter {

    public static void main(String[] args) {

        for (int i = 0; i < 5; i++) {
            System.out.println("Value of i is " + i);
        }

    }
}
