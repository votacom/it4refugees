/**
 * Prints whether I like pizza.
 */
public class Pizza {

    public static void main(String[] args) {

        boolean iLikePizza = true;

        if (iLikePizza) {
            System.out.println("Of course I like pizza!");
        } else {
            System.out.println("No, I don't like pizza.");
        }


    }
}
