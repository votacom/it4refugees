/**
 * computes area and circumference of a circle with given radius
 */
public class Circle {

    public static void main(String[] args) {

        final double PI = 3.14159265359;
        final double radius = 50; // in millimeters

        double area; // in square millimeters
        double circumference; // in millimeters

        // TODO what code to put here?

        System.out.println("The circle's area is " + area + " square millimeters");
        System.out.println("The circle's circumference is " + circumference + " millimeters"); // TODO: what if we want to print it in meters?

    }

}
